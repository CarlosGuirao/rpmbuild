# foonathan_memory_vendor

Vendor package for foonathan/memory: https://github.com/foonathan/memory

This package will download, patch, build and install foonathan_memory for its use with Fast-RTPS.

## Quality Declaration

This package claims to be in the **Quality Level 2** category, see the [Quality Declaration](QUALITY_DECLARATION.md) for more details.
