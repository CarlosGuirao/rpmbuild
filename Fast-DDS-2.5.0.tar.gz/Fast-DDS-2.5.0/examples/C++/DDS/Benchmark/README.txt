To launch this test open two different consoles:

In the first one launch: './DDSBenchmark publisher tcp' or './DDSBenchmark publisher udp' (or DDSBenchmark.exe publisher on windows).
In the second one: './DDSBenchmark subscriber tcp' or './DDSBenchmark subscriber udp'  (or DDSBenchmark.exe subscriber on windows).


