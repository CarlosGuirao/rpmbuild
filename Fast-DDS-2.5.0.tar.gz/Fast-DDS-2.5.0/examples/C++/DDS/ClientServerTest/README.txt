To launch this test open two different consoles:

In the first one launch: './DDSClientServerTest server' (or DDSClientServerTest.exe server on windows).
In the second one: './DDSClientServerTest client' (or DDSClientServerTest.exe client on windows).
