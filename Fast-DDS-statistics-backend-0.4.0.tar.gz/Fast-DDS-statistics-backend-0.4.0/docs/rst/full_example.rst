.. _full_example:

Full example
============

Next steps
""""""""""
You may find this example at the *eProsima Fast DDS Statistics Backend* Github repository, by following
`this <https://github.com/eProsima/Fast-DDS-statistics-backend/tree/master/examples/cpp/HelloWorldExample>`_ link.
