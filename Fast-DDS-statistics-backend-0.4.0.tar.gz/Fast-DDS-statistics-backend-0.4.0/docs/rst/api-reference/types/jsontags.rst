
.. _api_types_jsontags:

JSON Tags
---------

.. doxygenvariable:: ACTUAL_DUMP_VERSION
    :project: fastdds_statistics_backend

.. todo::

    Add every tag
