
.. _api_types_statistickind:

.. rst-class:: api-ref

StatisticKind
-------------

.. doxygenenum:: eprosima::statistics_backend::StatisticKind
    :project: fastdds_statistics_backend
