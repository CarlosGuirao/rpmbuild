
.. _api_types_entitykind:

.. rst-class:: api-ref

EntityKind
----------

.. doxygenenum:: eprosima::statistics_backend::EntityKind
    :project: fastdds_statistics_backend
