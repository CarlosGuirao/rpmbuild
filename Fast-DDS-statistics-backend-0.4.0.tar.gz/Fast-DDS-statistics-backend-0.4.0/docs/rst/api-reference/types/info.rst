.. _api_types_info:

.. rst-class:: api-ref

Info
----

.. doxygentypedef:: eprosima::statistics_backend::Info
    :project: fastdds_statistics_backend
