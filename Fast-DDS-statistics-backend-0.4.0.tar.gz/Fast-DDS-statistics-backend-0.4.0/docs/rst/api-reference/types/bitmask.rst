
.. _api_types_bitmask:

.. rst-class:: api-ref

Bitmask
-------

.. doxygenclass:: eprosima::statistics_backend::Bitmask
    :project: fastdds_statistics_backend
    :members:
