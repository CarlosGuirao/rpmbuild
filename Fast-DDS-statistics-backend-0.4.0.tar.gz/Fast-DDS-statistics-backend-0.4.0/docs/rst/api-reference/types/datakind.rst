
.. _api_types_datakind:

.. rst-class:: api-ref

DataKind
--------

.. doxygenenum:: eprosima::statistics_backend::DataKind
    :project: fastdds_statistics_backend
