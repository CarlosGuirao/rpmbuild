.. _api_types_graph:

.. rst-class:: api-ref

Graph
-----

.. doxygentypedef:: eprosima::statistics_backend::Graph
    :project: fastdds_statistics_backend
