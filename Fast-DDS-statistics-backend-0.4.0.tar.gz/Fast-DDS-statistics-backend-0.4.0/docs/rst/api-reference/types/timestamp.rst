.. _api_types_timestamp:

.. rst-class:: api-ref

Timestamp
---------

.. doxygentypedef:: eprosima::statistics_backend::Timestamp
    :project: fastdds_statistics_backend
