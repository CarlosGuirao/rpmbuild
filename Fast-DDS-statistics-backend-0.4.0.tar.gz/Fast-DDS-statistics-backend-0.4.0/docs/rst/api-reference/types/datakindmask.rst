.. _api_types_datakindmask:

.. rst-class:: api-ref

DataKindMask
------------

.. doxygentypedef:: eprosima::statistics_backend::DataKindMask
    :project: fastdds_statistics_backend
