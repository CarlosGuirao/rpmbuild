.. _api_types_domainid:

.. rst-class:: api-ref

DomainId
--------

.. doxygentypedef:: eprosima::statistics_backend::DomainId
    :project: fastdds_statistics_backend
