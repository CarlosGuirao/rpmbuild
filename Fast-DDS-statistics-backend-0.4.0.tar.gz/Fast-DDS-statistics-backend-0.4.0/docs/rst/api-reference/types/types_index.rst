.. _api_types:

Types
=====

.. toctree::

    /rst/api-reference/types/bitmask
    /rst/api-reference/types/datakind
    /rst/api-reference/types/datakindmask
    /rst/api-reference/types/domainid
    /rst/api-reference/types/entityid
    /rst/api-reference/types/entitykind
    /rst/api-reference/types/graph
    /rst/api-reference/types/info
    /rst/api-reference/types/statistickind
    /rst/api-reference/types/statisticsdata
    /rst/api-reference/types/timestamp
    /rst/api-reference/types/jsontags
