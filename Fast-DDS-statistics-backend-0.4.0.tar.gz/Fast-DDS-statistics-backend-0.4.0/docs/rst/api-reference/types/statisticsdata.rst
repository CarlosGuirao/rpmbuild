.. _api_types_statisticsdata:

.. rst-class:: api-ref

StatisticsData
--------------

.. doxygentypedef:: eprosima::statistics_backend::StatisticsData
    :project: fastdds_statistics_backend
