.. _api_exception_error:

.. rst-class:: api-ref

Error
-----

.. doxygenclass:: eprosima::statistics_backend::Error
    :project: fastdds_statistics_backend
    :members:
