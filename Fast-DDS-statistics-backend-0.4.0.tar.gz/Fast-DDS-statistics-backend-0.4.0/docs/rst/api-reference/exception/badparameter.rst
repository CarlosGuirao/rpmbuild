.. _api_exception_badparameter:

.. rst-class:: api-ref

BadParameter
------------

.. doxygenclass:: eprosima::statistics_backend::BadParameter
    :project: fastdds_statistics_backend
    :members:
