.. _api_exception_exception:

.. rst-class:: api-ref

Exception
---------

.. doxygenclass:: eprosima::statistics_backend::Exception
    :project: fastdds_statistics_backend
    :members:
