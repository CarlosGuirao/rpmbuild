.. _api_exception_preconditionnotmet:

.. rst-class:: api-ref

PreconditionNotMet
------------------

.. doxygenclass:: eprosima::statistics_backend::PreconditionNotMet
    :project: fastdds_statistics_backend
    :members:
