.. _api_exception_corruptedfile:

.. rst-class:: api-ref

CorruptedFile
-------------

.. doxygenclass:: eprosima::statistics_backend::CorruptedFile
    :project: fastdds_statistics_backend
    :members:
