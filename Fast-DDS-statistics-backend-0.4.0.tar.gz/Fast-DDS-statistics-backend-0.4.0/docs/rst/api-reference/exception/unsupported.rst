.. _api_exception_unsupported:

.. rst-class:: api-ref

Unsupported
-----------

.. doxygenclass:: eprosima::statistics_backend::Unsupported
    :project: fastdds_statistics_backend
    :members:
