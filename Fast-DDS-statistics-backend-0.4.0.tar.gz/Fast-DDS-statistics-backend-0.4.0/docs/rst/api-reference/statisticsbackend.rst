.. _api_exception_statisticsbackend:

.. rst-class:: api-ref

StatisticsBackend
-----------------

.. doxygenclass:: eprosima::statistics_backend::StatisticsBackend
    :project: fastdds_statistics_backend
    :members:
