.. _api_listener_callbackkind:

.. rst-class:: api-ref

CallbackKind
------------

.. doxygenenum:: eprosima::statistics_backend::CallbackKind
    :project: fastdds_statistics_backend
