.. _api_listener_callbackmask:

.. rst-class:: api-ref

CallbackMask
------------

.. doxygentypedef:: eprosima::statistics_backend::CallbackMask
    :project: fastdds_statistics_backend
