.. _api_listener_domainlistener:

.. rst-class:: api-ref

DomainListener
--------------

.. doxygenclass:: eprosima::statistics_backend::DomainListener
    :project: fastdds_statistics_backend
    :members:
