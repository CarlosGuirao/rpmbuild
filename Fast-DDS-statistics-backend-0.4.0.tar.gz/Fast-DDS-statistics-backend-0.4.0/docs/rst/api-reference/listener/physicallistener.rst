.. _api_listener_physicallistener:

.. rst-class:: api-ref

PhysicalListener
----------------

.. doxygenclass:: eprosima::statistics_backend::PhysicalListener
    :project: fastdds_statistics_backend
    :members:
