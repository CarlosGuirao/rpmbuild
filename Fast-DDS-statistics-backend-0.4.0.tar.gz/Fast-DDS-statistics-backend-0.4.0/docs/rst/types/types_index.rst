.. include:: ../exports/alias.include

.. _types:

Types
=====

.. toctree::

    /rst/types/data_kind
    /rst/types/statistic_kind
    /rst/types/entity_kind
    /rst/types/entity_id
    /rst/types/json_tags
    /rst/types/database_dumps
