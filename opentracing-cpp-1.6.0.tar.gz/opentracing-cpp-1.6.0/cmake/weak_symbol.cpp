void __attribute((weak)) f();

int main() { return 0; }
