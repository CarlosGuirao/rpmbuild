// Copyright 2019-20 Glyn Matthews.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef SKYR_CORE_URL_RECORD_HPP
#define SKYR_CORE_URL_RECORD_HPP

#include <skyr/v1/core/url_record.hpp>

#endif // SKYR_CORE_URL_RECORD_HPP
